<footer class="container-fluid text-center">
	<h3>Desarrollado por <a href="#">@ovedfs</a></h3>
</footer>